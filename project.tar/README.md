# authors-haven-api
DevOps development for demo created with Django, Docker, Celery, Redis, Nginx, Django Rest Framework and more...🦢🔥
